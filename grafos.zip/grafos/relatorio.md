# Grafos em Mobilidade Urbana: Conectividade, Rotas Alternativas e Gargalos no Bairro da Urca (RJ)

**Tema 5 — Algoritmos em Grafos** · Estudo de caso com dados reais do OpenStreetMap

---

## Resumo

Este trabalho modela a malha viária **real** do bairro da **Urca** (Rio de
Janeiro) como um grafo dirigido e ponderado e a analisa usando **exclusivamente
algoritmos vistos na disciplina**: percurso em grafos (BFS/DFS), as definições
formais de conexidade, articulação e ponte, caminhos mínimos (Dijkstra e
Bellman-Ford) e fluxo máximo / corte mínimo (Edmonds-Karp). Os dados das ruas
foram obtidos do OpenStreetMap (a mesma fonte usada por bibliotecas como o
OSMnx) e convertidos em grafo de interseções. Os resultados refletem fielmente a
geografia da Urca: o bairro é fisicamente conexo, mas as ruas de mão única
deixam **23 das 60 interseções fora da componente fortemente conexa**; o corredor
que liga a parte residencial ao restante do bairro é um **gargalo crítico** — o
**corte mínimo entre as duas zonas é de uma única rua**, cuja interdição
desconecta 125 de 293 pares origem-destino testados. Dentro da grade residencial,
ao contrário, há redundância: uma rua bloqueada gera apenas +13,6% no tempo de
viagem por uma rota alternativa. Todas as análises rodam em menos de 1 segundo.

---

## 1. Introdução

A mobilidade em uma cidade depende da topologia da sua malha de ruas.
Engarrafamentos, bairros mal servidos e a vulnerabilidade a acidentes ou obras
são, em boa medida, propriedades **estruturais** do grafo subjacente. A teoria
dos grafos — e os algoritmos estudados na disciplina — permite medir essas
propriedades de forma objetiva.

Escolhemos o bairro da **Urca**, no Rio de Janeiro, como estudo de caso. A Urca é
uma península ocupada por uma área residencial em grade, ligada ao restante da
cidade (Praia Vermelha / Av. Pasteur) por um corredor muito estreito. Essa
geografia faz do bairro um laboratório natural para os três eixos do Tema 5:

1. **Conectividade** — quais interseções são mutuamente alcançáveis de carro,
   considerando as ruas de mão única?
2. **Rotas alternativas** — existe caminho alternativo quando uma rua é
   bloqueada (obra, acidente)?
3. **Gargalos** — quais ruas/cruzamentos, se interrompidos, isolam parte do
   bairro?

Para que a análise seja realista, a rede de ruas foi extraída do
**OpenStreetMap** (OSM). Conforme orientação, **toda a análise usa somente
algoritmos vistos em sala**; nenhuma biblioteca de grafos foi utilizada — os
algoritmos foram implementados do zero.

---

## 2. Conceitos, Definições e Trabalhos Relacionados

Todos os conceitos abaixo foram apresentados na disciplina.

### 2.1 Grafo dirigido e ponderado

Modelamos a malha como $G = (V, E, w)$: cada vértice é uma **interseção**, cada
arco é um **trecho de rua** e $w$ é o tempo de viagem ($\text{comprimento} /
\text{velocidade}$). Uma rua de **mão dupla** vira dois arcos $(u,v)$ e $(v,u)$;
uma de **mão única**, um único arco. O sentido importa para o motorista, por isso
o grafo é dirigido.

### 2.2 Percurso em grafos (BFS e DFS)

A **busca em largura (BFS)** e a **busca em profundidade (DFS)** percorrem o
grafo em $O(V+E)$. Entre suas aplicações vistas em sala estão **encontrar
componentes conexas** e detectar alcançabilidade — base de toda a análise de
conectividade deste trabalho.

### 2.3 Conexidade, articulação e ponte (definições)

- **Grafo fracamente conexo:** seu grafo subjacente (ignorando o sentido) é
  conexo.
- **Grafo fortemente conexo:** existe caminho dirigido entre qualquer par de
  vértices, nos dois sentidos.
- **Articulação:** vértice $v$ que, se removido, torna o grafo desconexo.
- **Ponte:** aresta que, se removida, torna o grafo desconexo.

Estas são exatamente as definições formais apresentadas em sala. Note que elas
são *construtivas*: para testar se um vértice (ou aresta) é articulação (ou
ponte), basta **removê-lo e verificar, com BFS, se o número de componentes
aumentou** — foi assim que as implementamos, sem recorrer a algoritmos não vistos
(como o de Tarjan).

### 2.4 Caminho mínimo: Dijkstra e Bellman-Ford

- **Dijkstra:** caminho de custo mínimo a partir de uma origem, para pesos não
  negativos. Com heap binário, $O((V+E)\log V)$.
- **Bellman-Ford:** caminho mínimo em $O(V \cdot E)$, válido inclusive com pesos
  negativos. Como a malha viária não tem pesos negativos, usamo-lo como
  **verificação independente** do Dijkstra (ambos vistos em sala).

A disciplina também apresentou Floyd-Warshall e Johnson (todos os pares); aqui o
problema é de origem única, então Dijkstra/Bellman-Ford são suficientes.

### 2.5 Fluxo máximo e corte mínimo (Ford-Fulkerson / Edmonds-Karp)

O **algoritmo de Ford-Fulkerson** encontra o fluxo máximo de uma origem $O$ a um
destino $D$ buscando repetidamente *caminhos aumentantes* na rede residual; a
variante **Edmonds-Karp** usa BFS para achar esses caminhos, custando
$O(V\,E^2)$. O **Teorema do Fluxo Máximo / Corte Mínimo** (visto em sala) afirma:

> O valor máximo de um fluxo $O$–$D$ é igual à capacidade mínima de um corte que
> separa $O$ de $D$.

Atribuindo **capacidade 1 a cada rua**, o fluxo máximo entre duas regiões é o
número de rotas por ruas distintas (aresta-disjuntas) e o corte mínimo é o menor
conjunto de ruas cuja interdição isola uma região da outra — ou seja, **o
gargalo** da rede. É a aplicação direta do teorema à mobilidade urbana.

### 2.6 Trabalhos relacionados

A modelagem de redes viárias como grafos é consolidada. A biblioteca **OSMnx**
(Boeing, 2017) extrai grafos de ruas do OpenStreetMap e os simplifica para
interseções — exatamente o pré-processamento que reproduzimos aqui de forma
enxuta. Usamos o OSM apenas como **fonte de dados**; toda a análise é feita pelos
algoritmos da disciplina, implementados por nós.

---

## 3. Metodologia e Implementação

### 3.1 Obtenção e construção do grafo (mapa → grafo)

1. **Download:** consultamos a *Overpass API* do OpenStreetMap pelas vias
   (`highway`) dirigíveis dentro do *bounding box* da Urca. Os dados brutos são
   salvos em cache local (`data/urca.json`) para reprodutibilidade.
2. **Grafo completo:** cada via é uma sequência de pontos; pares consecutivos
   viram arcos. O sentido respeita as etiquetas `oneway` do OSM (mão única,
   rotatória, etc.).
3. **Simplificação topológica:** os pontos que são apenas "dobras" da rua
   (vértices de grau 2) são contraídos, restando apenas as **interseções reais**
   (grau ≠ 2). Sem isso, cada curva da rua viraria uma falsa articulação. É o
   mesmo procedimento do OSMnx, feito manualmente.
4. **Projeção:** as coordenadas (lat/lon) são projetadas para metros, para medir
   distâncias e desenhar o mapa.

Resultado: de **319 pontos** OSM (79 vias) restam **60 interseções**, **95
arcos** e **89 trechos de rua**.

### 3.2 Algoritmos implementados (somente conteúdo da disciplina)

| Análise | Algoritmo/definição da disciplina |
|---|---|
| Componentes conexas | BFS sobre o grafo não-dirigido |
| Componentes fortemente conexas | **definição**: BFS no grafo e no grafo reverso; a CFC de $s$ é a interseção dos alcançáveis nos dois sentidos |
| Articulações | **definição**: remover o vértice e recontar componentes (BFS) |
| Pontes | **definição**: remover a aresta e recontar componentes (BFS) |
| Caminho mínimo / rota | **Dijkstra** (heap binário) |
| Verificação do caminho mínimo | **Bellman-Ford** |
| Rota alternativa | **Dijkstra** após bloquear o trecho |
| Gargalo (corte) | **Edmonds-Karp** (fluxo máximo / corte mínimo) |

### 3.3 Decisões relevantes

- **Estrutural × dirigido:** componentes, articulações e pontes usam o grafo
  **não-dirigido** (a rua existe independentemente do sentido); já a conexidade
  forte e os caminhos mínimos usam o grafo **dirigido**.
- **Sem viés de sobrevivência na resiliência:** ao fechar um trecho, o tempo
  médio antes/depois é medido **só sobre pares que continuam conectados nos dois
  cenários**; os pares que ficam desconectados são contados à parte.

---

## 4. Resultados

A rede tem **60 interseções**, **95 arcos** e **89 trechos**. Todas as análises
juntas rodam em **0,64 s**. A Figura 1 (`01_urca.png`) mostra o mapa.

### 4.1 Conectividade

| Métrica | Valor |
|---|---|
| Componentes (não-dirigido) | **1** (bairro fisicamente conexo) |
| Componentes fortemente conexas | **18** |
| Maior CFC | **37** interseções |
| Interseções fora da CFC gigante | **23** |
| Ruas sem saída (cul-de-sac) | 5 |

A Urca é **fisicamente conexa** (uma componente), mas **longe de fortemente
conexa**: 23 das 60 interseções (38%) ficam **fora** do núcleo fortemente conexo
de 37 vértices. A causa são as numerosas **ruas de mão única**, que criam
interseções de onde se pode entrar mas não retornar pelo mesmo trajeto. É um
resultado prático importante: a noção correta de "dá para ir e voltar de carro" é
a de **componente fortemente conexa**, não a de simples conexidade física
(Figura 2, `02_scc.png`).

### 4.2 Gargalos estruturais (pontes e articulações)

| Métrica | Valor |
|---|---|
| Pontos de articulação | **9** de 60 interseções |
| Pontes (cut-edges) | **9** de 89 trechos |

As pontes (Figura 3, `03_criticos.png`) concentram-se no **corredor que liga a
grade residencial à Praia Vermelha** e nos acessos às ruas sem saída. São
**pontos únicos de falha**: a interdição de qualquer um deles parte o bairro.
Note que isso decorre diretamente da definição vista em sala — foram detectados
removendo cada trecho e checando, com BFS, se o grafo se desconecta.

### 4.3 Gargalo por fluxo máximo / corte mínimo

Tomando como origem $O$ uma interseção da grade residencial e como destino $D$
uma interseção do lado da Praia Vermelha, e capacidade 1 por rua, o
**Edmonds-Karp** retornou (Figura 4, `04_corte_minimo.png`):

| Métrica | Valor |
|---|---|
| Fluxo máximo (rotas por ruas distintas) | **1** |
| Corte mínimo (ruas que isolam $O$ de $D$) | **1** |

O resultado é contundente e geograficamente fiel: **uma única rua** liga toda a
parte residencial da Urca ao restante. Pelo Teorema do Fluxo Máximo / Corte
Mínimo, isso significa que **há apenas uma rota por ruas distintas** entre as duas
zonas — não há redundância. Esse é o maior gargalo do bairro.

### 4.4 Rotas alternativas (Dijkstra)

Para um par origem-destino **dentro da grade residencial** (onde há redundância),
o **Dijkstra** encontrou a rota principal em **2,77 min**; o **Bellman-Ford**
confirmou o mesmo custo (verificação independente).

Ao **bloquear um trecho** da rota (simulando obra/acidente) e recalcular com
Dijkstra, surge uma **rota alternativa de 3,15 min — apenas +13,6%**. Ou seja,
dentro da grade a malha é redundante (Figura 5, `05_rotas.png`).

Já a viagem entre as duas zonas do bairro atravessa **3 pontes**: fechar
qualquer uma delas **desconecta** a origem do destino — não há rota alternativa,
confirmando o gargalo da §4.3.

### 4.5 Resiliência

Fechando a rua do corredor (a ponte mais crítica), sobre uma amostra de 293
pares origem-destino da CFC gigante:

| Métrica | Valor |
|---|---|
| Tempo médio (pares ainda conectados) | 0,96 → 0,96 min (**+0,0%**) |
| Pares **recém-desconectados** | **125** |

O tempo médio dos pares que sobrevivem quase não muda, mas **125 pares ficam sem
qualquer rota** — exatamente o comportamento de um corte de capacidade 1: o
trecho não é "lento", é **insubstituível**. Eis o contraste central do trabalho:
dentro da grade, bloquear uma rua custa +13,6%; no corredor, bloquear a rua
**isola o bairro**.

### 4.6 Desempenho

| Etapa | Tempo |
|---|---|
| Conectividade (BFS, CFC) | 0,7 ms |
| Articulações + pontes (definição) | 3,8 ms |
| Corte mínimo (Edmonds-Karp) | 0,3 ms |
| Dijkstra / Bellman-Ford | 0,1 / 0,1 ms |
| **Total** | **0,64 s** |

Os tempos são coerentes com as complexidades vistas em sala. A etapa mais cara é
a de articulações/pontes, pois a abordagem pela definição executa um BFS por
vértice/aresta ($O(V \cdot (V+E))$ e $O(E \cdot (V+E))$); ainda assim é
instantânea nesta rede.

---

## 5. Conclusão

Usando **apenas algoritmos da disciplina** sobre a malha viária **real** da Urca,
respondemos aos três eixos do Tema 5:

- **Conectividade:** a noção relevante para mobilidade é a de **componente
  fortemente conexa** (BFS no grafo e no reverso). As muitas mãos únicas da Urca
  deixam 38% das interseções fora do núcleo fortemente conexo.
- **Rotas alternativas:** com **Dijkstra**, dentro da grade residencial há
  redundância (uma rua bloqueada custa só +13,6%); entre as duas zonas do bairro,
  porém, a rota cruza pontes e **não há alternativa**.
- **Gargalos:** as **pontes/articulações** (pela definição) e o **corte mínimo**
  (Edmonds-Karp) convergem para a mesma conclusão — o corredor de acesso à parte
  residencial é um gargalo de **capacidade 1**, cuja interdição isola o bairro.

O estudo mostra como conceitos clássicos de grafos descrevem com precisão um
problema urbano concreto, e como a escolha do algoritmo certo (conexidade forte,
corte mínimo) revela vulnerabilidades que uma análise ingênua não veria.
**Trabalhos futuros:** usar capacidades realistas (faixas) no fluxo máximo;
aplicar Floyd-Warshall para medir o "diâmetro" do bairro; e estender a análise a
bairros maiores.

---

## 6. Referências

1. CORMEN, T. H.; LEISERSON, C. E.; RIVEST, R. L.; STEIN, C. *Introduction to
   Algorithms*. 3. ed. MIT Press, 2009.
2. DIJKSTRA, E. W. A note on two problems in connexion with graphs.
   *Numerische Mathematik*, v. 1, p. 269–271, 1959.
3. BELLMAN, R. On a routing problem. *Quarterly of Applied Mathematics*, v. 16,
   p. 87–90, 1958.
4. FORD, L. R.; FULKERSON, D. R. *Flows in Networks*. Princeton University
   Press, 1962.
5. EDMONDS, J.; KARP, R. M. Theoretical improvements in algorithmic efficiency
   for network flow problems. *Journal of the ACM*, v. 19, n. 2, p. 248–264, 1972.
6. BOEING, G. OSMnx: New methods for acquiring, constructing, analyzing, and
   visualizing complex street networks. *Computers, Environment and Urban
   Systems*, v. 65, p. 126–139, 2017.
7. OpenStreetMap contributors. *OpenStreetMap*. Dados sob licença ODbL.
   Disponível em: https://www.openstreetmap.org.
