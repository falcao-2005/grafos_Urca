"""
Pipeline principal — Tema 5: Grafos em mobilidade urbana
Estudo de caso: bairro da URCA (Rio de Janeiro), dados reais do OpenStreetMap.

Usa SOMENTE algoritmos vistos na disciplina:
  (A) CONECTIVIDADE      -> BFS/DFS; componentes; fortemente conexo (BFS no
                            grafo e no reverso); articulacoes e pontes pela
                            definicao.
  (B) ROTAS ALTERNATIVAS -> Dijkstra (e Bellman-Ford como verificacao);
                            rota alternativa recalculada ao bloquear um trecho.
  (C) GARGALOS           -> estruturais (pontes/articulacoes) e por
                            fluxo maximo / corte minimo (Edmonds-Karp).

Gera figuras (output/) e metricas (output/metrics.json).

Uso:  py main.py
"""

from __future__ import annotations
import json
import math
import os
import random
import time

from osm_loader import load_neighborhood
import connectivity as cc
import shortest_paths as sp
import maxflow as mf
import visualize as viz

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "output")
os.makedirs(OUT, exist_ok=True)

# Bairro da Urca, RJ (bounding box S,W,N,E)
NEIGHBORHOOD = "urca"
BBOX = "-22.958,-43.171,-22.943,-43.155"


def banner(t):
    print("\n" + "=" * 64 + f"\n {t}\n" + "=" * 64)


def main():
    t0_all = time.perf_counter()
    metrics = {}

    # ----------------------------------------------------------- carrega mapa
    data = load_neighborhood(NEIGHBORHOOD, BBOX)
    G = data["graph"]
    edges_u = [(u, v) for (u, v, _, _) in data["undirected_edges"]]
    nodes = G.nodes()
    banner("REDE DE RUAS — URCA (RJ), OpenStreetMap")
    print(f"Pontos OSM brutos: {data['n_raw_nodes']} | vias OSM: {data['n_ways']}")
    print(f"Apos simplificacao: {G.n} intersecoes (V), {G.m} arcos (E), "
          f"{len(edges_u)} trechos de rua")
    metrics["rede"] = {
        "fonte": "OpenStreetMap (Overpass API)",
        "bairro": "Urca, Rio de Janeiro",
        "bbox": BBOX,
        "pontos_osm": data["n_raw_nodes"],
        "vias_osm": data["n_ways"],
        "V_intersecoes": G.n,
        "E_arcos": G.m,
        "trechos": len(edges_u),
    }
    viz.fig_overview(data, os.path.join(OUT, "01_urca.png"))

    # --------------------------------------------------------- conectividade
    banner("(A) CONECTIVIDADE")
    t0 = time.perf_counter()
    comps = cc.connected_components(nodes, edges_u)
    scc = cc.strongly_connected_components(G)
    t_conn = time.perf_counter() - t0
    comp_sizes = sorted((len(c) for c in comps), reverse=True)
    scc_sizes = sorted((len(c) for c in scc), reverse=True)
    deg = {u: 0 for u in nodes}
    for (u, v) in edges_u:
        deg[u] += 1; deg[v] += 1
    dead_ends = [u for u in nodes if deg[u] == 1]
    n_nao_triviais = sum(1 for c in scc if len(c) > 1)
    print(f"Componentes (nao-dirigido): {len(comps)} (maior = {comp_sizes[0]})")
    print(f"Componentes fortemente conexas: {len(scc)} (maior = {scc_sizes[0]})")
    print(f"Intersecoes fora da CFC gigante: {G.n - scc_sizes[0]} "
          f"(efeito das mãos únicas)")
    print(f"Ruas sem saida (cul-de-sac, grau 1): {len(dead_ends)}")
    print(f"Tempo: {t_conn*1000:.1f} ms")
    metrics["conectividade"] = {
        "componentes": len(comps),
        "maior_componente": comp_sizes[0],
        "scc": len(scc),
        "maior_scc": scc_sizes[0],
        "fora_da_scc_gigante": G.n - scc_sizes[0],
        "ruas_sem_saida": len(dead_ends),
        "tempo_ms": round(t_conn * 1000, 2),
    }
    viz.fig_scc(data, scc, os.path.join(OUT, "02_scc.png"))

    # ---------------------------------------------- gargalos estruturais
    banner("(C.1) GARGALOS ESTRUTURAIS: pontes e articulacoes (definicao)")
    t0 = time.perf_counter()
    aps = cc.articulation_points(nodes, edges_u)
    brs = cc.bridges(nodes, edges_u)
    t_struct = time.perf_counter() - t0
    print(f"Pontos de articulacao: {len(aps)} de {G.n} intersecoes")
    print(f"Pontes (cut-edges): {len(brs)} de {len(edges_u)} trechos")
    print(f"Tempo: {t_struct*1000:.1f} ms")
    metrics["gargalos_estruturais"] = {
        "articulacoes": len(aps),
        "pontes": len(brs),
        "tempo_ms": round(t_struct * 1000, 2),
    }
    viz.fig_critical(data, brs, aps, os.path.join(OUT, "03_criticos.png"))

    # ---- escolhe origem (O) e destino (D) extremos da peninsula -----------
    # O = interseccao mais ao norte/leste (grade residencial)
    # D = interseccao mais ao sul/oeste (saida em direcao a cidade)
    giant = max(scc, key=len)
    gset = set(giant)
    # nós bem conectados (grau >= 3) da CFC gigante, para que O e D nao sejam
    # cul-de-sacs locais e o corte minimo reflita o "pescoço" do bairro.
    inner = [u for u in gset if deg[u] >= 3] or list(gset)
    O = max(inner, key=lambda u: G.coords[u][0] + G.coords[u][1])
    D = min(inner, key=lambda u: G.coords[u][0] + G.coords[u][1])

    # ---------------------------------------------- gargalo por fluxo/corte
    banner("(C.2) GARGALOS POR FLUXO MAXIMO / CORTE MINIMO (Edmonds-Karp)")
    cap = mf.unit_capacity_network(data["undirected_edges"])
    t0 = time.perf_counter()
    fmax, flow, reach, cut = mf.edmonds_karp(nodes, cap, O, D)
    t_flow = time.perf_counter() - t0
    print(f"Origem O={O}  Destino D={D}")
    print(f"Fluxo maximo (rotas por ruas distintas): {int(fmax)}")
    print(f"Corte minimo (ruas que isolam O de D): {len(cut)}")
    print(f"  -> {cut}")
    print(f"Tempo Edmonds-Karp: {t_flow*1000:.1f} ms")
    metrics["gargalo_corte_minimo"] = {
        "origem": O, "destino": D,
        "fluxo_maximo": int(fmax),
        "corte_minimo": len(cut),
        "ruas_do_corte": [list(e) for e in cut],
        "tempo_ms": round(t_flow * 1000, 2),
    }
    viz.fig_mincut(data, O, D, cut, reach, fmax,
                   os.path.join(OUT, "04_corte_minimo.png"))

    # ---------------------------------------------------- rotas alternativas
    banner("(B) ROTAS ALTERNATIVAS (Dijkstra)")
    # par O-D DENTRO da grade residencial (onde a malha oferece redundancia),
    # para demonstrar de fato uma rota alternativa.
    grid = [u for u in giant if G.coords[u][1] > 150] or list(giant)
    Or = max(grid, key=lambda u: G.coords[u][0])
    Dr = min(grid, key=lambda u: G.coords[u][0])
    t0 = time.perf_counter()
    main_route, main_cost = sp.shortest_path(G, Or, Dr)
    t_dij = time.perf_counter() - t0
    # verificacao independente com Bellman-Ford
    t0 = time.perf_counter()
    bf_dist, _ = sp.bellman_ford(G, Or)
    t_bf = time.perf_counter() - t0
    bf_cost = bf_dist.get(Dr, math.inf)
    confere = abs(bf_cost - main_cost) < 1e-6

    # bloqueia um trecho da rota principal (preferindo uma ponte/corte) e
    # recalcula -> rota alternativa
    # Para DEMONSTRAR uma rota alternativa, bloqueia um trecho da rota que NAO
    # seja ponte (assim existe desvio pela malha). Trechos do meio primeiro.
    bridge_set = {frozenset(e) for e in brs}
    route_pairs = list(zip(main_route, main_route[1:])) if main_route else []
    order = sorted(range(len(route_pairs)),
                   key=lambda i: abs(i - len(route_pairs) / 2))
    blocked_edge = None
    for i in order:
        a, b = route_pairs[i]
        if frozenset((a, b)) not in bridge_set:
            blocked_edge = (a, b)
            break
    # quantas pontes a rota atravessa (trechos sem alternativa)
    route_bridges = [pair for pair in route_pairs
                     if frozenset(pair) in bridge_set]
    blocked = {blocked_edge, (blocked_edge[1], blocked_edge[0])} if blocked_edge else set()
    alt_route, alt_cost = sp.alternative_route(G, Or, Dr, blocked)

    print(f"Rota principal: {main_cost/60:.2f} min, {len(main_route)} intersecoes")
    print(f"Verificacao Bellman-Ford: {bf_cost/60:.2f} min "
          f"({'confere' if confere else 'DIVERGE'}); "
          f"Dijkstra {t_dij*1000:.1f} ms vs Bellman-Ford {t_bf*1000:.1f} ms")
    print(f"Origem Or={Or}  Destino Dr={Dr}  (dentro da grade residencial)")
    if alt_route:
        extra = 100.0 * (alt_cost - main_cost) / main_cost
        print(f"Trecho (nao-ponte) bloqueado: {blocked_edge}")
        print(f"Rota alternativa: {alt_cost/60:.2f} min  ({extra:+.1f}% vs principal)")
    else:
        print(f"Sem rota alternativa ao bloquear {blocked_edge}.")
    print(f"A rota atravessa {len(route_bridges)} ponte(s) — trechos SEM "
          f"alternativa (fechá-los desconecta a rota).")
    metrics["rotas_alternativas"] = {
        "origem": Or, "destino": Dr,
        "rota_principal_min": round(main_cost / 60, 2),
        "intersecoes_rota": len(main_route),
        "bellman_ford_confere": confere,
        "tempo_dijkstra_ms": round(t_dij * 1000, 2),
        "tempo_bellman_ford_ms": round(t_bf * 1000, 2),
        "trecho_bloqueado": list(blocked_edge) if blocked_edge else None,
        "rota_alternativa_min": (round(alt_cost / 60, 2)
                                 if alt_route else None),
        "acrescimo_pct": (round(100.0 * (alt_cost - main_cost) / main_cost, 1)
                          if alt_route else None),
        "pontes_na_rota": len(route_bridges),
    }
    viz.fig_routes(data, main_route, alt_route, Or, Dr, blocked,
                   os.path.join(OUT, "05_rotas.png"))

    # ------------------------------------------------------------ resiliencia
    banner("(C.3) RESILIENCIA: impacto de fechar um gargalo")
    rng = random.Random(7)
    gl = list(giant)
    od = [(rng.choice(gl), rng.choice(gl)) for _ in range(300)]
    od = [(a, b) for a, b in od if a != b]

    def avg_time(blocked_edges=None):
        tot, n, disc = 0.0, 0, 0
        base_ok = []
        for a, b in od:
            _, c = sp.shortest_path(G, a, b, blocked_edges=blocked_edges)
            base_ok.append(c)
        return base_ok

    base_costs = avg_time()
    base_inf = sum(1 for c in base_costs if c == math.inf)
    res = {}
    # escolhe a PONTE mais critica: a que, ao ser fechada, desconecta o maior
    # numero de pares O-D. Se nao houver pontes, usa uma aresta do corte minimo.
    target_edge = None
    if brs:
        best_disc = -1
        for e in brs:
            be = {e, (e[1], e[0])}
            nc = avg_time(blocked_edges=be)
            disc = sum(1 for c in nc if c == math.inf) - base_inf
            if disc > best_disc:
                best_disc = disc
                target_edge = e
    elif cut:
        target_edge = cut[0]
    if target_edge:
        be = {target_edge, (target_edge[1], target_edge[0])}
        new_costs = avg_time(blocked_edges=be)
        both = [(x, y) for x, y in zip(base_costs, new_costs)
                if x != math.inf and y != math.inf]
        base_avg = sum(x for x, _ in both) / len(both) if both else math.inf
        new_avg = sum(y for _, y in both) / len(both) if both else math.inf
        newly_disc = (sum(1 for c in new_costs if c == math.inf)
                      - sum(1 for c in base_costs if c == math.inf))
        delta = 100.0 * (new_avg - base_avg) / base_avg if base_avg else math.inf
        print(f"Fechando o trecho {target_edge}:")
        print(f"  tempo medio: {base_avg/60:.2f} -> {new_avg/60:.2f} min "
              f"({delta:+.1f}%) sobre {len(both)} pares conectados")
        print(f"  pares recem-desconectados: {newly_disc}")
        res = {
            "trecho_fechado": list(target_edge),
            "tipo": "ponte" if brs else "aresta do corte minimo",
            "tempo_base_min": round(base_avg / 60, 2),
            "tempo_novo_min": round(new_avg / 60, 2) if new_avg != math.inf else None,
            "variacao_pct": round(delta, 1) if delta != math.inf else None,
            "pares_desconectados": newly_disc,
            "amostra_od": len(od),
        }
    else:
        print("Nao ha pontes nem corte para testar.")
    metrics["resiliencia"] = res

    # ------------------------------------------------------------------ saida
    metrics["tempo_total_s"] = round(time.perf_counter() - t0_all, 2)
    with open(os.path.join(OUT, "metrics.json"), "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    banner("CONCLUIDO")
    print(f"Figuras e metricas em: {OUT}")
    print(f"Tempo total: {metrics['tempo_total_s']} s")


if __name__ == "__main__":
    main()
