"""
Visualizacoes da rede de ruas real (Urca/RJ) e dos resultados das analises.

Usa a geometria real das ruas (polilinhas do OpenStreetMap) para desenhar o
mapa. Backend 'Agg' para funcionar sem interface grafica.
"""

from __future__ import annotations
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection

# fontes maiores para boa leitura na impressao do artigo
plt.rcParams.update({
    "font.size": 13,
    "axes.titlesize": 15,
    "legend.fontsize": 12,
})


def _geom_lookup(data):
    """frozenset(u,v) -> geometria (lista de pontos), na ordem u->v."""
    lut = {}
    for (u, v, length, geom) in data["undirected_edges"]:
        lut[(u, v)] = geom
    return lut


def _route_segments(route, lut, G):
    """Lista de polilinhas (uma por arco do caminho)."""
    segs = []
    for a, b in zip(route, route[1:]):
        if (a, b) in lut:
            segs.extend(zip(lut[(a, b)], lut[(a, b)][1:]))
        elif (b, a) in lut:
            g = lut[(b, a)]
            segs.extend(zip(g, g[1:]))
        else:
            segs.append((G.coords[a], G.coords[b]))
    return segs


def draw_base(data, ax, color="#c2c7d0", lw=1.0, node_color="#9aa3b2"):
    G = data["graph"]
    segs = []
    for (u, v, length, geom) in data["undirected_edges"]:
        segs.extend(zip(geom, geom[1:]))
    ax.add_collection(LineCollection(segs, colors=color, linewidths=lw, zorder=1))
    xs = [c[0] for c in G.coords.values()]
    ys = [c[1] for c in G.coords.values()]
    ax.scatter(xs, ys, s=6, c=node_color, zorder=2)
    ax.set_aspect("equal"); ax.margins(0.04)
    ax.set_xticks([]); ax.set_yticks([])


def fig_overview(data, path):
    fig, ax = plt.subplots(figsize=(8.5, 8.5))
    draw_base(data, ax)
    G = data["graph"]
    ax.set_title(f"Bairro da Urca (RJ) — rede de ruas do OpenStreetMap\n"
                 f"{G.n} interseções, {len(data['undirected_edges'])} trechos "
                 f"(de {data['n_raw_nodes']} pontos OSM)")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def fig_scc(data, sccs, path):
    fig, ax = plt.subplots(figsize=(8.5, 8.5))
    draw_base(data, ax, color="#dfe3ea")
    G = data["graph"]
    cmap = plt.get_cmap("tab10")
    big = sorted(sccs, key=len, reverse=True)
    for i, comp in enumerate(big[:10]):
        xs = [G.coords[u][0] for u in comp]
        ys = [G.coords[u][1] for u in comp]
        lbl = f"CFC {i+1} ({len(comp)} nós)" if len(comp) > 1 else None
        ax.scatter(xs, ys, s=28, color=cmap(i % 10), zorder=5, label=lbl)
    ax.legend(loc="upper left", fontsize=12, framealpha=0.9)
    ax.set_title("Componentes fortemente conexas (alcançabilidade de carro)")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def fig_critical(data, br, ap, path):
    fig, ax = plt.subplots(figsize=(8.5, 8.5))
    draw_base(data, ax, color="#dfe3ea")
    G = data["graph"]
    lut = _geom_lookup(data)
    if br:
        segs = []
        for (u, v) in br:
            g = lut.get((u, v)) or lut.get((v, u))
            if g:
                segs.extend(zip(g, g[1:]))
            else:
                segs.append((G.coords[u], G.coords[v]))
        ax.add_collection(LineCollection(segs, colors="#e6194b",
                                         linewidths=3.2, zorder=4))
        ax.plot([], [], color="#e6194b", lw=3, label=f"pontes ({len(br)})")
    if ap:
        ax.scatter([G.coords[u][0] for u in ap],
                   [G.coords[u][1] for u in ap],
                   s=70, facecolors="none", edgecolors="#ff8c00",
                   linewidths=2.0, zorder=6,
                   label=f"articulações ({len(ap)})")
    ax.legend(loc="upper left", fontsize=12, framealpha=0.9)
    ax.set_title("Gargalos estruturais: pontes e pontos de articulação")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def fig_mincut(data, source, sink, cut_edges, reachable, maxflow, path):
    fig, ax = plt.subplots(figsize=(8.5, 8.5))
    G = data["graph"]
    lut = _geom_lookup(data)
    # ruas, coloridas conforme o lado do corte
    segs_s, segs_t = [], []
    for (u, v, length, geom) in data["undirected_edges"]:
        pts = list(zip(geom, geom[1:]))
        if u in reachable and v in reachable:
            segs_s.extend(pts)
        else:
            segs_t.extend(pts)
    ax.add_collection(LineCollection(segs_s, colors="#9ecae1", linewidths=1.4, zorder=1))
    ax.add_collection(LineCollection(segs_t, colors="#cbd2dc", linewidths=1.4, zorder=1))
    # arestas do corte minimo
    csegs = []
    for (u, v) in cut_edges:
        g = lut.get((u, v)) or lut.get((v, u))
        if g:
            csegs.extend(zip(g, g[1:]))
        else:
            csegs.append((G.coords[u], G.coords[v]))
    ax.add_collection(LineCollection(csegs, colors="#e6194b", linewidths=3.6, zorder=5))
    ax.plot([], [], color="#e6194b", lw=3,
            label=f"corte mínimo = {len(cut_edges)} rua(s)")
    for node, lbl, col in [(source, "O", "#1a7d1a"), (sink, "D", "#000")]:
        x, y = G.coords[node]
        ax.scatter([x], [y], s=160, color=col, zorder=8)
        ax.text(x, y, lbl, color="white", ha="center", va="center",
                fontsize=12, fontweight="bold", zorder=9)
    ax.scatter([], [], color="#9ecae1", label="lado da origem (O)")
    ax.set_aspect("equal"); ax.margins(0.04)
    ax.set_xticks([]); ax.set_yticks([])
    ax.legend(loc="upper left", fontsize=12, framealpha=0.9)
    ax.set_title(f"Gargalo por fluxo máximo / corte mínimo\n"
                 f"fluxo máximo = {int(maxflow)} rotas distintas; "
                 f"corte mínimo = {len(cut_edges)} rua(s)")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def fig_routes(data, main_route, alt_route, s, t, blocked, path):
    fig, ax = plt.subplots(figsize=(8.5, 8.5))
    draw_base(data, ax, color="#dfe3ea")
    G = data["graph"]
    lut = _geom_lookup(data)
    if main_route:
        ax.add_collection(LineCollection(
            _route_segments(main_route, lut, G), colors="#e6194b",
            linewidths=3.4, zorder=5, label="rota principal (Dijkstra)"))
    if alt_route:
        ax.add_collection(LineCollection(
            _route_segments(alt_route, lut, G), colors="#4363d8",
            linewidths=3.0, linestyles="dashed", zorder=4,
            label="rota alternativa (trecho bloqueado)"))
    if blocked:
        for (u, v) in blocked:
            g = lut.get((u, v)) or lut.get((v, u))
            if g:
                ax.add_collection(LineCollection(list(zip(g, g[1:])),
                                  colors="#000", linewidths=2.0, zorder=6))
        ax.plot([], [], color="#000", lw=2, label="trecho bloqueado")
    for node, lbl in [(s, "O"), (t, "D")]:
        x, y = G.coords[node]
        ax.scatter([x], [y], s=150, color="#000", zorder=8)
        ax.text(x, y, lbl, color="white", ha="center", va="center",
                fontsize=12, fontweight="bold", zorder=9)
    ax.legend(loc="upper left", fontsize=12, framealpha=0.9)
    ax.set_title("Rotas alternativas (Dijkstra)")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)
