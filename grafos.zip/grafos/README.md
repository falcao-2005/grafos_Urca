# Tema 5 — Grafos em Mobilidade Urbana (Bairro da Urca, RJ)

Análise de **conectividade**, **rotas alternativas** e **gargalos** na malha
viária **real** do bairro da Urca (Rio de Janeiro), extraída do OpenStreetMap.

Restrição do trabalho: **usa apenas algoritmos vistos na disciplina** — BFS/DFS,
definições de conexidade/articulação/ponte, Dijkstra, Bellman-Ford e fluxo
máximo / corte mínimo (Edmonds-Karp). Nenhuma biblioteca de grafos é usada; os
algoritmos são implementados do zero. O OpenStreetMap entra apenas como **fonte
de dados** (papel que o OSMnx teria).

## Como executar

Requisitos: Python 3.10+, `matplotlib`. O download do OSM precisa de internet na
primeira execução (depois fica em cache em `data/urca.json`).

```bash
cd src
py main.py          # roda toda a análise e gera as figuras
cd ..
py make_pdf.py      # gera o relatorio.pdf a partir das figuras
```

Saídas em `output/`:

- `01_urca.png` — mapa do bairro (rede de ruas do OSM).
- `02_scc.png` — componentes fortemente conexas (alcançabilidade de carro).
- `03_criticos.png` — pontes e pontos de articulação (gargalos estruturais).
- `04_corte_minimo.png` — corte mínimo (Edmonds-Karp) isolando a grade residencial.
- `05_rotas.png` — rota principal e rota alternativa (Dijkstra).
- `metrics.json` — todas as métricas numéricas.

## Estrutura do código

| Arquivo | Responsabilidade | Conteúdo da disciplina |
|---|---|---|
| `src/osm_loader.py` | Baixa o mapa do OSM e o converte em grafo de interseções (com simplificação, como o OSMnx) | — (pré-processamento) |
| `src/graph.py` | Estrutura do grafo (listas de adjacência direta e reversa) | — |
| `src/connectivity.py` | BFS, DFS, componentes, CFC (BFS + reverso), articulações e pontes (pela definição) | Percurso em grafos; conexidade |
| `src/shortest_paths.py` | Dijkstra, Bellman-Ford, rota alternativa | Caminho mínimo |
| `src/maxflow.py` | Edmonds-Karp (fluxo máximo / corte mínimo) | Fluxo máximo |
| `src/visualize.py` | Figuras sobre o mapa real | — |
| `src/main.py` | Orquestra as análises | — |

## Mapeamento Tema 5 → algoritmos da disciplina

- **Conectividade** → BFS/DFS; CFC pela definição (BFS no grafo e no reverso).
- **Gargalos estruturais** → articulações e pontes pela **definição** (remover e
  recontar componentes com BFS).
- **Gargalo de capacidade** → **fluxo máximo / corte mínimo** (Edmonds-Karp).
- **Rotas alternativas** → **Dijkstra** (e **Bellman-Ford** como verificação);
  recalcular a rota ao bloquear um trecho.

## Relatório

[`relatorio.md`](relatorio.md) (e o [`relatorio.pdf`](relatorio.pdf) gerado)
seguem a estrutura do enunciado: Introdução, Conceitos/Definições, Metodologia,
Resultados, Conclusão e Referências.

## Principais resultados (Urca)

- 60 interseções, 95 arcos, 89 trechos (de 319 pontos OSM).
- Fisicamente conexa, mas **23 de 60 interseções fora da CFC gigante** (mãos únicas).
- 9 pontes e 9 articulações; **corte mínimo entre as duas zonas = 1 rua**.
- Dentro da grade: rota alternativa custa só **+13,6%**. No corredor: fechar a
  ponte **desconecta 125 de 293 pares** (gargalo de capacidade 1).

## Fonte dos dados

© OpenStreetMap contributors, sob licença ODbL — https://www.openstreetmap.org
