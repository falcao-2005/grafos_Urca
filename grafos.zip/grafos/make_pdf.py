"""
Gera o relatorio em PDF (relatorio.pdf) — versao Urca (dados reais do OSM),
usando reportlab (texto/tabelas) e as figuras geradas pelo pipeline.

Uso:  py make_pdf.py   (rode antes:  py src/main.py)
"""

from __future__ import annotations
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER
from reportlab.lib.utils import ImageReader
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Image,
    Table, TableStyle, KeepTogether, HRFlowable,
)

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(ROOT, "output")
PDF = os.path.join(ROOT, "relatorio.pdf")
CONTENT_W = A4[0] - 4 * cm

styles = getSampleStyleSheet()
S = {
    "title": ParagraphStyle("title", parent=styles["Title"], fontSize=17,
                            leading=21, spaceAfter=4, textColor=colors.HexColor("#1a2a44")),
    "subtitle": ParagraphStyle("subtitle", parent=styles["Normal"], fontSize=10.5,
                               alignment=TA_CENTER, textColor=colors.HexColor("#555"),
                               spaceAfter=12),
    "h1": ParagraphStyle("h1", parent=styles["Heading1"], fontSize=14, leading=18,
                         spaceBefore=14, spaceAfter=6, textColor=colors.HexColor("#1a2a44")),
    "h2": ParagraphStyle("h2", parent=styles["Heading2"], fontSize=11.5, leading=15,
                         spaceBefore=10, spaceAfter=4, textColor=colors.HexColor("#2b4a7a")),
    "body": ParagraphStyle("body", parent=styles["Normal"], fontSize=9.7, leading=14,
                           alignment=TA_JUSTIFY, spaceAfter=6),
    "abstract": ParagraphStyle("abstract", parent=styles["Normal"], fontSize=9.3,
                               leading=13, alignment=TA_JUSTIFY, spaceAfter=6,
                               leftIndent=10, rightIndent=10, textColor=colors.HexColor("#333")),
    "caption": ParagraphStyle("caption", parent=styles["Normal"], fontSize=8.3,
                              leading=11, alignment=TA_CENTER,
                              textColor=colors.HexColor("#555"), spaceBefore=3, spaceAfter=12),
    "cell": ParagraphStyle("cell", parent=styles["Normal"], fontSize=8.6, leading=11),
    "cellh": ParagraphStyle("cellh", parent=styles["Normal"], fontSize=8.6, leading=11,
                            textColor=colors.white),
    "li": ParagraphStyle("li", parent=styles["Normal"], fontSize=9.7, leading=14,
                         alignment=TA_JUSTIFY, leftIndent=14, bulletIndent=4, spaceAfter=4),
    "ref": ParagraphStyle("ref", parent=styles["Normal"], fontSize=9, leading=12.5,
                          leftIndent=16, firstLineIndent=-12, spaceAfter=3),
}


def img_flowable(path, max_w=CONTENT_W, max_h=20 * cm):
    iw, ih = ImageReader(path).getSize()
    w = max_w; h = w * ih / iw
    if h > max_h:
        h = max_h; w = h * iw / ih
    return Image(path, width=w, height=h)


def figure_block(filename, caption, max_h=10.5 * cm):
    return KeepTogether([
        img_flowable(os.path.join(OUT, filename), max_w=CONTENT_W, max_h=max_h),
        Paragraph(caption, S["caption"]),
    ])


def para(t): return Paragraph(t, S["body"])
def bullet(t): return Paragraph(t, S["li"], bulletText="•")


def table(headers, rows, col_w=None, highlight_rows=None):
    highlight_rows = highlight_rows or set()
    data = [[Paragraph(h, S["cellh"]) for h in headers]]
    for r in rows:
        data.append([Paragraph(str(c), S["cell"]) for c in r])
    t = Table(data, colWidths=col_w, hAlign="CENTER")
    ts = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2b4a7a")),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#bcc4d2")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#eef2f8")]),
    ]
    for ri in highlight_rows:
        ts.append(("BACKGROUND", (0, ri), (-1, ri), colors.HexColor("#fde2e2")))
    t.setStyle(TableStyle(ts))
    return t


def build():
    story = []
    A = story.append

    A(Paragraph("Grafos em Mobilidade Urbana", S["title"]))
    A(Paragraph("Conectividade, Rotas Alternativas e Gargalos no Bairro da Urca (RJ)",
                ParagraphStyle("t2", parent=S["title"], fontSize=12, spaceAfter=6)))
    A(Paragraph("Tema 5 &nbsp;•&nbsp; Algoritmos em Grafos &nbsp;•&nbsp; "
                "estudo de caso com dados reais do OpenStreetMap", S["subtitle"]))
    A(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor("#2b4a7a"), spaceAfter=10))

    A(Paragraph("Resumo", S["h2"]))
    A(Paragraph(
        "Este trabalho modela a malha viária <b>real</b> do bairro da <b>Urca</b> "
        "(Rio de Janeiro) como um grafo dirigido e ponderado e a analisa usando "
        "<b>exclusivamente algoritmos vistos na disciplina</b>: percurso em grafos "
        "(BFS/DFS), as definições de conexidade, articulação e ponte, caminhos "
        "mínimos (Dijkstra e Bellman-Ford) e fluxo máximo / corte mínimo "
        "(Edmonds-Karp). Os dados das ruas vêm do OpenStreetMap (mesma fonte do "
        "OSMnx) e foram convertidos em grafo de interseções. Os resultados refletem "
        "a geografia da Urca: o bairro é fisicamente conexo, mas as ruas de mão "
        "única deixam <b>23 das 60 interseções fora da componente fortemente "
        "conexa</b>; o corredor que liga a parte residencial ao restante é um "
        "<b>gargalo crítico</b> — o <b>corte mínimo entre as duas zonas é de uma "
        "única rua</b>, cuja interdição desconecta 125 de 293 pares testados. "
        "Dentro da grade residencial há redundância: uma rua bloqueada custa apenas "
        "+13,6% no tempo de viagem. Tudo roda em menos de 1 segundo.", S["abstract"]))

    A(Paragraph("1. Introdução", S["h1"]))
    A(para(
        "A mobilidade em uma cidade depende da topologia da malha de ruas. "
        "Engarrafamentos, bairros mal servidos e a vulnerabilidade a obras são, em "
        "boa medida, propriedades <b>estruturais</b> do grafo subjacente. Escolhemos "
        "o bairro da <b>Urca</b> (RJ): uma península com área residencial em grade, "
        "ligada ao restante da cidade (Praia Vermelha / Av. Pasteur) por um corredor "
        "muito estreito — um laboratório natural para os três eixos do Tema 5:"))
    A(bullet("<b>Conectividade</b> — quais interseções são mutuamente alcançáveis de "
             "carro, dadas as ruas de mão única?"))
    A(bullet("<b>Rotas alternativas</b> — há caminho alternativo quando uma rua é "
             "bloqueada?"))
    A(bullet("<b>Gargalos</b> — quais ruas/cruzamentos, se interrompidos, isolam "
             "parte do bairro?"))
    A(para(
        "A rede foi extraída do <b>OpenStreetMap</b>. Conforme orientação, "
        "<b>toda a análise usa somente algoritmos vistos em sala</b>; nenhuma "
        "biblioteca de grafos foi usada — os algoritmos foram implementados do zero."))
    A(figure_block("01_urca.png",
                   "<b>Figura 1.</b> Bairro da Urca (RJ): rede de ruas do "
                   "OpenStreetMap, simplificada para interseções.", max_h=9.5 * cm))

    A(Paragraph("2. Conceitos e Definições (todos vistos na disciplina)", S["h1"]))
    A(Paragraph("2.1 Grafo dirigido e ponderado", S["h2"]))
    A(para(
        "Modelamos a malha como G = (V, E, w): cada vértice é uma <b>interseção</b>, "
        "cada arco é um <b>trecho de rua</b> e w é o tempo de viagem "
        "(comprimento / velocidade). Mão dupla vira dois arcos (u,v) e (v,u); mão "
        "única, um único arco. O grafo é dirigido porque o sentido importa."))
    A(Paragraph("2.2 Percurso em grafos (BFS e DFS)", S["h2"]))
    A(para(
        "BFS e DFS percorrem o grafo em O(V+E). Entre as aplicações vistas em sala "
        "estão <b>encontrar componentes conexas</b> e testar alcançabilidade — base "
        "de toda a análise de conectividade deste trabalho."))
    A(Paragraph("2.3 Conexidade, articulação e ponte (definições)", S["h2"]))
    A(bullet("<b>Fracamente conexo:</b> o grafo subjacente (sem sentido) é conexo."))
    A(bullet("<b>Fortemente conexo:</b> há caminho dirigido entre qualquer par de "
             "vértices, nos dois sentidos."))
    A(bullet("<b>Articulação:</b> vértice que, se removido, desconecta o grafo."))
    A(bullet("<b>Ponte:</b> aresta que, se removida, desconecta o grafo."))
    A(para(
        "Essas definições são <i>construtivas</i>: para testar se um vértice/aresta é "
        "articulação/ponte, basta <b>removê-lo e verificar com BFS se o número de "
        "componentes aumentou</b> — foi assim que implementamos, sem usar algoritmos "
        "não vistos (como o de Tarjan)."))
    A(Paragraph("2.4 Caminho mínimo: Dijkstra e Bellman-Ford", S["h2"]))
    A(bullet("<b>Dijkstra</b> (heap binário): caminho mínimo com pesos não "
             "negativos, O((V+E) log V)."))
    A(bullet("<b>Bellman-Ford</b>: caminho mínimo em O(V·E); aqui serve de "
             "<b>verificação independente</b> do Dijkstra (ambos vistos em sala)."))
    A(Paragraph("2.5 Fluxo máximo e corte mínimo (Ford-Fulkerson / Edmonds-Karp)", S["h2"]))
    A(para(
        "<b>Ford-Fulkerson</b> acha o fluxo máximo de O a D por caminhos aumentantes "
        "na rede residual; <b>Edmonds-Karp</b> usa BFS para isso, em O(V·E²). O "
        "<b>Teorema do Fluxo Máximo / Corte Mínimo</b> (visto em sala) diz: "
        "<i>o valor máximo de um fluxo O–D é igual à capacidade mínima de um corte "
        "que separa O de D</i>. Atribuindo <b>capacidade 1 a cada rua</b>, o fluxo "
        "máximo entre duas regiões é o número de rotas por ruas distintas e o corte "
        "mínimo é o menor conjunto de ruas que isola uma região da outra — ou seja, "
        "<b>o gargalo</b> da rede."))
    A(Paragraph("2.6 Trabalhos relacionados", S["h2"]))
    A(para(
        "A biblioteca <b>OSMnx</b> (Boeing, 2017) extrai grafos de ruas do "
        "OpenStreetMap e os simplifica para interseções — o pré-processamento que "
        "reproduzimos aqui de forma enxuta. Usamos o OSM apenas como <b>fonte de "
        "dados</b>; a análise é toda feita pelos algoritmos da disciplina."))

    A(Paragraph("3. Metodologia e Implementação", S["h1"]))
    A(Paragraph("3.1 Do mapa ao grafo", S["h2"]))
    A(bullet("<b>Download:</b> consulta à <i>Overpass API</i> do OSM pelas vias "
             "dirigíveis no <i>bounding box</i> da Urca (com cache local)."))
    A(bullet("<b>Grafo completo:</b> pares de pontos consecutivos de cada via viram "
             "arcos; o sentido respeita as etiquetas <i>oneway</i> do OSM."))
    A(bullet("<b>Simplificação:</b> contraem-se os pontos de grau 2 (apenas curvas "
             "da rua), restando as <b>interseções reais</b>. Sem isso, cada curva "
             "viraria uma falsa articulação (mesmo procedimento do OSMnx)."))
    A(bullet("<b>Projeção:</b> lat/lon → metros, para medir distâncias e desenhar."))
    A(para(
        "Resultado: de <b>319 pontos</b> OSM (79 vias) restam <b>60 interseções</b>, "
        "<b>95 arcos</b> e <b>89 trechos</b>."))
    A(Paragraph("3.2 Algoritmos implementados (somente conteúdo da disciplina)", S["h2"]))
    A(table(
        ["Análise", "Algoritmo / definição da disciplina"],
        [["Componentes conexas", "BFS no grafo não-dirigido"],
         ["Comp. fortemente conexas", "definição: BFS no grafo e no reverso; CFC = interseção dos alcançáveis nos dois sentidos"],
         ["Articulações", "definição: remover vértice e recontar componentes (BFS)"],
         ["Pontes", "definição: remover aresta e recontar componentes (BFS)"],
         ["Caminho mínimo / rota", "Dijkstra (heap binário)"],
         ["Verificação", "Bellman-Ford"],
         ["Rota alternativa", "Dijkstra após bloquear o trecho"],
         ["Gargalo (corte)", "Edmonds-Karp (fluxo máximo / corte mínimo)"]],
        col_w=[4.6 * cm, CONTENT_W - 4.6 * cm]))

    A(Paragraph("4. Resultados", S["h1"]))
    A(para("A rede tem <b>60 interseções</b>, <b>95 arcos</b> e <b>89 trechos</b>. "
           "Todas as análises rodam em <b>0,64 s</b>."))

    A(Paragraph("4.1 Conectividade", S["h2"]))
    A(table(["Métrica", "Valor"],
            [["Componentes (não-dirigido)", "1 (bairro fisicamente conexo)"],
             ["Componentes fortemente conexas", "18"],
             ["Maior CFC", "37 interseções"],
             ["Interseções fora da CFC gigante", "23 (38%)"],
             ["Ruas sem saída (cul-de-sac)", "5"]],
            col_w=[8.5 * cm, CONTENT_W - 8.5 * cm]))
    A(Spacer(1, 6))
    A(para(
        "A Urca é <b>fisicamente conexa</b>, mas <b>longe de fortemente conexa</b>: "
        "23 das 60 interseções (38%) ficam <b>fora</b> do núcleo fortemente conexo "
        "de 37 vértices, por causa das numerosas <b>ruas de mão única</b> — de onde "
        "se entra mas não se retorna pelo mesmo trajeto. A noção correta de "
        "'dá para ir e voltar de carro' é a de <b>componente fortemente conexa</b>, "
        "não a de simples conexidade física."))
    A(figure_block("02_scc.png",
                   "<b>Figura 2.</b> Componentes fortemente conexas. Azul: a CFC "
                   "gigante (37 nós); coloridos: bolsões criados por mãos únicas."))

    A(Paragraph("4.2 Gargalos estruturais (pontes e articulações)", S["h2"]))
    A(table(["Métrica", "Valor"],
            [["Pontos de articulação", "9 de 60 interseções"],
             ["Pontes (cut-edges)", "9 de 89 trechos"]],
            col_w=[8.5 * cm, CONTENT_W - 8.5 * cm]))
    A(Spacer(1, 6))
    A(para(
        "As pontes concentram-se no <b>corredor que liga a grade residencial à "
        "Praia Vermelha</b> e nos acessos às ruas sem saída — <b>pontos únicos de "
        "falha</b>. Foram detectadas pela definição vista em sala: removendo cada "
        "trecho e checando, com BFS, se o grafo se desconecta."))
    A(figure_block("03_criticos.png",
                   "<b>Figura 3.</b> Gargalos estruturais: pontes (vermelho) e "
                   "articulações (laranja)."))

    A(Paragraph("4.3 Gargalo por fluxo máximo / corte mínimo", S["h2"]))
    A(para(
        "Com origem O na grade residencial, destino D do lado da Praia Vermelha e "
        "capacidade 1 por rua, o <b>Edmonds-Karp</b> retornou:"))
    A(table(["Métrica", "Valor"],
            [["Fluxo máximo (rotas por ruas distintas)", "1"],
             ["Corte mínimo (ruas que isolam O de D)", "1"]],
            col_w=[10 * cm, CONTENT_W - 10 * cm], highlight_rows={1, 2}))
    A(Spacer(1, 6))
    A(para(
        "Resultado contundente e geograficamente fiel: <b>uma única rua</b> liga "
        "toda a parte residencial da Urca ao restante. Pelo Teorema do Fluxo Máximo "
        "/ Corte Mínimo, <b>há apenas uma rota por ruas distintas</b> entre as duas "
        "zonas — sem redundância. É o maior gargalo do bairro."))
    A(figure_block("04_corte_minimo.png",
                   "<b>Figura 4.</b> Corte mínimo (vermelho) = 1 rua isola toda a "
                   "grade residencial (azul, lado de O) do resto (lado de D)."))

    A(Paragraph("4.4 Rotas alternativas (Dijkstra)", S["h2"]))
    A(para(
        "Para um par origem-destino <b>dentro da grade residencial</b>, o "
        "<b>Dijkstra</b> achou a rota principal em <b>2,77 min</b>; o "
        "<b>Bellman-Ford</b> confirmou o mesmo custo. Ao <b>bloquear um trecho</b> "
        "e recalcular, surge uma <b>rota alternativa de 3,15 min — apenas +13,6%</b>: "
        "dentro da grade a malha é redundante. Já a viagem entre as duas zonas "
        "atravessa <b>3 pontes</b>: fechar qualquer uma <b>desconecta</b> O de D — "
        "não há alternativa, confirmando o gargalo da seção 4.3."))
    A(figure_block("05_rotas.png",
                   "<b>Figura 5.</b> Rota principal (vermelho) e rota alternativa "
                   "(azul tracejado) ao bloquear um trecho (preto), na grade."))

    A(Paragraph("4.5 Resiliência", S["h2"]))
    A(table(["Métrica", "Valor"],
            [["Tempo médio (pares ainda conectados)", "0,96 → 0,96 min (+0,0%)"],
             ["Pares recém-desconectados", "125 (de 293)"]],
            col_w=[9 * cm, CONTENT_W - 9 * cm], highlight_rows={2}))
    A(Spacer(1, 6))
    A(para(
        "Fechando a rua do corredor (a ponte mais crítica), o tempo médio dos pares "
        "que sobrevivem quase não muda, mas <b>125 pares ficam sem qualquer rota</b> "
        "— o comportamento de um corte de capacidade 1: o trecho não é 'lento', é "
        "<b>insubstituível</b>. Contraste central: dentro da grade, bloquear uma rua "
        "custa +13,6%; no corredor, <b>isola o bairro</b>."))

    A(Paragraph("4.6 Desempenho", S["h2"]))
    A(table(["Etapa", "Tempo"],
            [["Conectividade (BFS, CFC)", "0,7 ms"],
             ["Articulações + pontes (definição)", "3,8 ms"],
             ["Corte mínimo (Edmonds-Karp)", "0,3 ms"],
             ["Dijkstra / Bellman-Ford", "0,1 / 0,1 ms"],
             ["Total", "0,64 s"]],
            col_w=[CONTENT_W - 4 * cm, 4 * cm]))
    A(Spacer(1, 6))
    A(para(
        "Os tempos são coerentes com as complexidades vistas em sala. A etapa mais "
        "cara é a de articulações/pontes, pois a abordagem pela definição executa um "
        "BFS por vértice/aresta; ainda assim é instantânea nesta rede."))

    A(Paragraph("5. Conclusão", S["h1"]))
    A(para("Usando <b>apenas algoritmos da disciplina</b> sobre a malha <b>real</b> "
           "da Urca, respondemos aos três eixos do Tema 5:"))
    A(bullet("<b>Conectividade:</b> a noção relevante é a de <b>componente fortemente "
             "conexa</b> (BFS no grafo e no reverso); as mãos únicas deixam 38% das "
             "interseções fora do núcleo fortemente conexo."))
    A(bullet("<b>Rotas alternativas:</b> com <b>Dijkstra</b>, há redundância dentro "
             "da grade (+13,6% ao bloquear uma rua); entre as duas zonas, a rota "
             "cruza pontes e <b>não há alternativa</b>."))
    A(bullet("<b>Gargalos:</b> <b>pontes/articulações</b> (definição) e <b>corte "
             "mínimo</b> (Edmonds-Karp) convergem: o corredor de acesso é um gargalo "
             "de <b>capacidade 1</b>, cuja interdição isola o bairro."))
    A(para(
        "O estudo mostra como conceitos clássicos de grafos descrevem com precisão um "
        "problema urbano real, e como escolher o algoritmo certo (conexidade forte, "
        "corte mínimo) revela vulnerabilidades que uma análise ingênua não veria. "
        "<b>Trabalhos futuros:</b> capacidades realistas (faixas) no fluxo máximo; "
        "Floyd-Warshall para o 'diâmetro' do bairro; e bairros maiores."))

    A(Paragraph("6. Referências", S["h1"]))
    refs = [
        "CORMEN, T. H. et al. <i>Introduction to Algorithms</i>. 3. ed. MIT Press, 2009.",
        "DIJKSTRA, E. W. A note on two problems in connexion with graphs. <i>Numerische Mathematik</i>, v. 1, p. 269–271, 1959.",
        "BELLMAN, R. On a routing problem. <i>Quarterly of Applied Mathematics</i>, v. 16, p. 87–90, 1958.",
        "FORD, L. R.; FULKERSON, D. R. <i>Flows in Networks</i>. Princeton University Press, 1962.",
        "EDMONDS, J.; KARP, R. M. Theoretical improvements in algorithmic efficiency for network flow problems. <i>Journal of the ACM</i>, v. 19, n. 2, p. 248–264, 1972.",
        "BOEING, G. OSMnx: New methods for acquiring, constructing, analyzing, and visualizing complex street networks. <i>Computers, Environment and Urban Systems</i>, v. 65, p. 126–139, 2017.",
        "OpenStreetMap contributors. <i>OpenStreetMap</i> (dados sob licença ODbL). https://www.openstreetmap.org.",
    ]
    for i, r in enumerate(refs, 1):
        A(Paragraph(f"[{i}] {r}", S["ref"]))

    doc = BaseDocTemplate(PDF, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                          topMargin=1.8 * cm, bottomMargin=1.8 * cm,
                          title="Tema 5 - Mobilidade Urbana (Urca)")
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id="main")

    def footer(canvas, d):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(colors.HexColor("#888"))
        canvas.drawCentredString(A4[0] / 2, 1.0 * cm,
                                 f"Tema 5 — Mobilidade Urbana · Urca (RJ)    ·    pág. {d.page}")
        canvas.restoreState()

    doc.addPageTemplates([PageTemplate(id="main", frames=[frame], onPage=footer)])
    doc.build(story)
    print(f"PDF gerado: {PDF}")


if __name__ == "__main__":
    build()
